// export const trendingRecipes = [
//     { id: 1, name: "Chocolate Cake", rating: 4.5, price: "INR 250", image: "/path/to/image1.jpg" },
//     { id: 2, name: "Salad Bowl", rating: 4.3, price: "INR 150", image: "/path/to/image2.jpg" },
//     { id: 3, name: "Grilled Veggies", rating: 4.6, price: "INR 300", image: "/path/to/image3.jpg" },
//     { id: 4, name: "Pasta Delight", rating: 4.2, price: "INR 200", image: "/path/to/image4.jpg" },
// ];

// export const categories = [
//     { name: "Dessert", image: "/path/to/category1.jpg" },
//     { name: "Main Course", image: "/path/to/category2.jpg" },
//     { name: "Snacks", image: "/path/to/category3.jpg" },
//     { name: "Drinks", image: "/path/to/category4.jpg" },
// ];
